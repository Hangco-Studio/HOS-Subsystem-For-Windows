import random
import sys
import datetime
import time
import os
from datetime import datetime
try:
    file = open("language.HOS")
    language = file.readline()
    file.close()
except:
    print("-"*50)
    os.system("install.py")
    print("-"*50)
    file = open("language.HOS")
    language = file.readline()
    file.close()
try:
    import pygame
    os.system("cls")
    pygame.mixer.init()
except:
    if language == 'en':
        print("Your havn't install 'pygame' module yet!")
    else:
        print("您还没有安装pygame模块。")
    time.sleep(1)
    exit()
def getWord():
    try:
        file = open("pass.HOS","r")
        key = file.readline()
        file.close()
        while True:
            if key == '':
                break
            if language == 'en':
                password = input("Please enter the password : ")
                if password == key:
                    print("Pass!")
                    break
                else:
                    print("Your password is wrong!!!")
            else:
                password = input("请输入密码：")
                if password == key:
                    print("通过！")
                    break
                else:
                    print("密码错误！")
    except:
        if language == 'en':
            password = input("Please enter the new password: ")
            key1 = open("pass.HOS","w")
            key1.write(password)
            key1.close()
        else:
            password = input("请输入新的密码：")
            key1 = open("pass.HOS","w")
            key1.write(password)
            key1.close()

def getName():
    try:
        user = open("user.HOS","r")
        username = user.readline()
        user.close()
    except:
        if language == 'en':
            username = input("Please enter your name : ")
            user = open("user.HOS","w")
            user.write(username)
            user.close()
        else:
            username = input("请输入您的姓名：")
            user = open("user.HOS","w")
            user.write(username)
            user.close()
    sound = pygame.mixer.Sound("files/sounds/power1.wav")
    sound.play()
    if language == 'en':
        print("Welcome to HOS, "+username+"! You can enter 'commandList' for more information.")
        print("Copyright Hangco Inc. All rights reserved.")
    else:
        print("欢迎来到HOS, "+username+"！您可以通过输入'commandList'命令来获取命令列表。")
        print("Copyright Hangco Inc. All rights reserved.")

def main():
    file = open("user.HOS")
    username = file.readline()
    file.close()
    if language == 'en':
        command = input("username: "+username+" $ ")
    else:
        command = input("用户名："+username+" $ ")
    return command

def commandList():
    if language == 'en':
        print("-"*50)
        print("Command1: commandList\tHOS's command list")
        print("Command2: file\t HOS's file system ")
        print("Command3: quit\tquit HOS")
        print("Command4: ver\tOutput version.")
        print("Command5: sys\tOutput your system(Not HOS!!!).")
        print("Command6: time\tHOS's time system.")
        print("Command7: command\tcommand prompt.")
        print("Command8: vm\tHOS's vms.")
        print("Command9: readme\tsome readme text.")
        print("Command10: setup\tHOS's setup.")
        print("Command11: jackpot\tjackpot game.")
        print("Command12: chatbot\tchat with mike, a chat robot.")
        print("Command13: pyBrowser\tWeb Browser (Please install PyQt5!!!)")
        print("Command14: soundPlayer\tHOS's sound player")
        print("Command15: pyShell\tshell.")
        print("-"*50)
    else:
        print("-"*50)
        print("命令1：commandList\t显示命令列表")
        print("命令2：file\t管理文件")
        print("命令3：quit\t退出HOS")
        print("命令4：ver\t显示HOS的版本")
        print("命令5：sys\t显示您的操作系统的一些信息")
        print("命令6：time\t时间系统")
        print("命令7：command\t您的操作系统自带命令解释器command")
        print("Command8: vm\t虚拟机")
        print("Command9: readme\treadme文档")
        print("Command10: setup\t设置HOS")
        print("Command11: jackpot\tjackpot游戏")
        print("Command12: chatbot\t和聊天机器人MIKE聊天")
        print("Command13: pyBrowser\t访问互联网（请安装PyQt5）")
        print("Command14: soundPlayer\t音乐播放器")
        print("Command15: pyShell\tshell")
        print("-"*50)

def fileman():
    if language == 'en':
        print("-"*50)
        command = input("Please enter 'newFile', 'alterFile', 'seeFile', 'delFile': ")
                
        if command == 'newFile':
            fileName = input("Please enter the new file's name : ")
            try:
                if fileName == '':
                    print("Error!")
                else:
                    print("Creating......")
                    newFile = open(fileName,"w")
                    fileContent = input("Please enter the new file's content : ")
                    newFile.write(fileContent)
                    print("Create Sucsessfully!")
                    newFile.close()
            except PermissionError:
                print("PermissionError!")

        elif command == 'alterFile':
            try:
                fileName = input("Please enter the file's name that you want to alter : ")
                alterType = input("Please enter the type that you want to alter (w/a, w is write, a is add) : ")
                alterFile = open(fileName,alterType)
                if alterType == 'w':
                    fileContent = input("Please enter the new file content that you want to alter : ")
                elif alterType == 'a':
                    fileContent = input("Please enter the file content that you want to add : ")
                    print("Altering......")
                    alterFile.write(fileContent)
                    print("Alter sucsessfully!")
                    alterFile.close()
            except:
                print("No such file named " + fileName +"!")

        elif command == 'seeFile':
            try:
                file = open(input("Please enter the file's name: "))
                text = file.readline()
                print(text)
                for something in text:
                    text = file.readline()
                    print(text)
                    if not readme:
                        print("-"*50)
                        break
            except:
                print("No such file named " + fileName +"!")      

        elif command == 'delFile':
            try:
                fileName = input("Please enter the file's name that you want to delete : ")
                yn = input("Do you really want to delete this file? (y/n) : ")
                if yn == 'Y' or yn == 'y':
                    os.remove(fileName)
                elif yn == 'N' or yn == 'n':
                    return
            except:
                print("Name "+command+" not found!")

        else:
            print("Name "+command+" not found!")

        print("-"*50)
    else:
        print("-"*50)
        command = input("请您输入newFile、alterFile、seeFile或openFile：")
                
        if command == 'newFile':
            fileName = input("请输入新文件的名字：")
            try:
                if fileName == '':
                    print("错误：名字不能为空")
                else:
                    print("创建中。。。")
                    newFile = open(fileName,"w")
                    fileContent = input("请输入新的文件的内容：")
                    newFile.write(fileContent)
                    print("创建成功！")
                    newFile.close()
            except PermissionError:
                print("不合法的文件名")

        elif command == 'alterFile':
            try:
                fileName = input("请输入您想修改的文件的目录和名字：")
                alterType = input("请输入您想修改文件的方法（w是重新写入，a是增加内容）：")
                alterFile = open(fileName,alterType)
                if alterType == 'w':
                    fileContent = input("请输入文件新的内容：")
                elif alterType == 'a':
                    fileContent = input("请输入要增加的内容：")
                    print("正在修改。。。")
                    alterFile.write(fileContent)
                    print("修改成功！")
                    alterFile.close()
            except:
                print("没有那么多的文件！")

        elif command == 'seeFile':
            try:
                file = open(input("请输入要查看的文件的名字："))
                text = file.readline()
                print(text)
                for something in text:
                    text = file.readline()
                    print(text)
                    if not readme:
                        print("-"*50)
                        break
            except:
                print("没有这么多的文件！")      

        elif command == 'delFile':
            try:
                fileName = input("请输入您想删除的文件的名字：")
                yn = input("您的确要删除这个文件吗？（Y/N）：")
                if yn == 'Y' or yn == 'y':
                    os.remove(fileName)
                elif yn == 'N' or yn == 'n':
                    return
            except:
                print("发生错误！")

        else:
            print("没有找到该命令！")

        print("-"*50)

def ver():
    if language == 'en':
        print("-"*50)
        print("HOS NT V6.3 , Built on 20200911SP002 Technology, Codename: Super Technology")
        print("-"*50)
    else:
        print("-"*50)
        print("版本号：HOS NT 6.3，构建于20200911SP002技术，别称：超级技术")
        print("-"*50)

def quitHOS():
    if language == 'en':
        print("-"*50)
        print("Quit sucessfully.")
        print("-"*50)
        sound = r'files/sounds/power2.wav'
        track = pygame.mixer.music.load(sound)
        pygame.mixer.music.play()
        time.sleep(10)
        pygame.mixer.music.stop()
    else:
        print("-"*50)
        print("退出成功！")
        print("-"*50)
        sound = r'files/sounds/power2.wav'
        track = pygame.mixer.music.load(sound)
        pygame.mixer.music.play()
        time.sleep(10)
        pygame.mixer.music.stop()

def outputime():
    if language == 'en':
        print("-"*50)
        command = input("What do you want? time or timer : ")

        if command == 'time':
            print(datetime.now())

        elif command == 'timer':
            ttime = input("How much time do you want to time? : ")
            itime = int(ttime)
            while itime >= 0.00000:
                import time
                time.sleep(1.00000)
                itime = itime - 1
            print("Time over!!!")
            sound = pygame.mixer.Sound("timeOver.wav")
            sound.play()

        else:
            print("Command "+command+" not found!")

        print("-"*50)
    else:
        print("-"*50)
        command = input("请输入time或timer：")

        if command == 'time':
            print("当前时间：",datetime.now())

        elif command == 'timer':
            ttime = input("请输入您想计时多长时间：")
            itime = int(ttime)
            while itime >= 0:
                time.sleep(1.00000)
                itime = itime - 1
            print("时间到啦！")
            for time in len(ttime):
                sound = pygame.mixer.Sound("timeOver.wav")
                sound.play()

        else:
            print("没有找到该命令")

        print("-"*50)
    
def sysfun():
    if language == 'en':
        print("-"*50)
        print("Your os is ", sys.platform)
        print("Your python's version is ", sys.version)
        print(sys.copyright)
        print("-"*50)
    else:
        print("-"*50)
        print("您的系统架构：", sys.platform)
        print("您的Python版本：", sys.version)
        print(sys.copyright)
        print("-"*50)

def cmd():
    if language == 'en':
        print("-"*50)
        while True:
            tcmd = input("Command Prompt $ ")
            if tcmd == 'exit':
                print("-"*50)
                break
            else:
                os.system(tcmd)
    else:
        print("-"*50)
        while True:
            tcmd = input("命令解释器 $ ")
            if tcmd == 'exit':
                print("-"*50)
                break
            else:
                os.system(tcmd)

def vm():
    os.system("cls")
    os.system('aseros.bat')

def readme():
    if language == 'en':
        print("-"*50)
        file = open("readme_en.txt","r")
        readme = file.readline()
        print(readme)
        for text in readme:
            readme = file.readline()
            print(readme,end="")
            if not readme:
                print()
                print("-"*50)
                break
    else:
        print("-"*50)
        file = open("readme_en.txt","r")
        readme = file.readline()
        print(readme)
        for text in readme:
            readme = file.readline()
            print(readme,end="")
            if not readme:
                print()
                print("-"*50)
                break

def setup():
    if language == 'en':
        print("-"*50)
        password = input("Please enter the password to continue : ")
        file = open("pass.HOS")
        key = file.readline()
        file.close()
        if password == key:
            print("Pass!")
            command = input("Please enter setup command 'password' or 'shutdown' : ")
            if command == 'password':
                file = open("pass.HOS","w")
                password = input("Please enter the new password : ")
                file.write(password)
                print("Alter Succsessfully")
                file.close()
            elif command == 'shutdown':
                if sys.platform == 'win32' or sys.platform == 'win64':
                    os.system("shutdown -s -t 0")
                else:
                    print("This process requird Microsoft Windows.")
                    time.sleep(1)
        else:
            print("Your password is wrong!")
        print("-"*50)
    else:
        print("-"*50)
        password = input("请输入密码：")
        file = open("pass.HOS")
        key = file.readline()
        file.close()
        if password == key:
            print("通过！")
            command = input("请输入 'password' 或者 'shutdown'：")
            if command == 'password':
                file = open("pass.HOS","w")
                password = input("请输入新的密码：")
                file.write(password)
                print("修改成功！")
                file.close()
            elif command == 'shutdown':
                if sys.platform == 'win32' or sys.platform == 'win64':
                    os.system("shutdown -s -t 0")
                else:
                    print("请通过使用Microsoft Windows来继续")
                    time.sleep(1)
        else:
            print("密码错误！")
        print("-"*50)

def jackpot():
    os.system("jackpot.exe")
    print("**game end**")

def chatbot():
    if language == 'en':
        print("-"*50)
        os.system("chatbot.exe")
        print("-"*50)
    else:
        print("-"*50)
        os.system("chatbot_zh.exe")
        print("-"*50)

def pyBrowser():
    print("-"*50)
    os.system("pyBrowser.py")
    print("-"*50)

def soundPlayer():
    if language == 'en':
        print("-"*50)
        try:
            tsound = input("Please enter the sound's path and the sound's name: ")
            sound = pygame.mixer.Sound(tsound)
            sound.play()
            print("You are now playing "+tsound)
        except:
            print("Error!")
        print("-"*50)
    else:
        print("-"*50)
        try:
            tsound = input("请输入音效的文件位置和文件名：")
            sound = pygame.mixer.Sound(tsound)
            sound.play()
            print("您正在播放 "+tsound)
        except:
            print("错误！")
        print("-"*50)

def pyShell():
    if language == 'en':
        print("-"*50)
        print("Welcome to Pyshell, you can type 'listcmd' for more information.")
        while True:
            command = input("pyShell $ ")
            if command == 'listcmd':
                print("Command1: listcmd\tShow all the commands.")
                print("Command2: quit\tQuit PyShell.")
            elif command == 'quit':
                break
        print("-"*50)

def bad():
    if language == 'en':
        print("-"*50)
        print("Command '",command,"' is a bad command!")
        print("-"*50)
    else:
        print("-"*50)
        print("未找到该命令")
        print("-"*50)

getWord()
getName()
while True:
    command = main()
    if command == "commandList":
        commandList()
        continue
    elif command == "file":
        fileman()
        continue
    elif command == "ver":
        ver()
        continue
    elif command == "quit":
        quitHOS()
        break
    elif command == "time":
        outputime()
        continue
    elif command == "sys":
        sysfun()
        continue
    elif command == "command":
        cmd()
        continue
    elif command == "vm":
        vm()
        continue
    elif command == "readme":
        readme()
        continue
    elif command == "setup":
        setup()
        continue
    elif command == "jackpot":
        jackpot()
        continue
    elif command == "chatbot":
        chatbot()
        continue
    elif command == "pyBrowser":
        pyBrowser()
        continue
    elif command == "soundPlayer":
        soundPlayer()
        continue
    elif command == 'pyShell':
        pyShell()
    else:
        if command == '':
            continue
        else:
            bad()
            continue
