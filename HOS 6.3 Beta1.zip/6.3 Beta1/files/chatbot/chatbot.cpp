#include<iostream>
#include<string>
#include<sstream>
#include<ctime> 
#include<cstdlib>
#define M 5
using namespace std;
string greet[M]={"Hello boy!",
				"Hello Earthman!",
				"What's the order?",
				"Ask me questions.",
				"Ha ha."}; 				 
string joke[M]={"Xiao Ming bought a book that taught people how to fall asleep quickly, and saw the dawn every day.",
				"I am the commander-in-chief of the navy of Inner Mongolia.",
				"Judge: Why do you want to print fake banknotes? The defendant said innocently: because I will not print real money.",
				"First Thieves: Count how much money you robbed today? Second thief: No, you will find out by reading the newspaper tomorrow.",
				"Mom: What is your specialty? Xiao Hong: I burnt it...Boiled water is not bad!"};
string sorry[M]={"Sorry, my IQ is too low to understand.",
				"Let me think...",
				"I am not going to answer this question.",
				"No comment.",
				"I'll tell you next time."};
bool allDigits(string s){
	for(int i=0;i<s.size();i++)
		if(s[i]<'0'||s[i]>'9') return 0;
	return 1;
}

void decompose(string s){
	stringstream ss;
	int n,c=0;
	ss<<s; ss>>n;
	if(n<=1) {cout<<"Mike: This number is too small: "<<n<<", I can't seem to break it down"<<endl;return;} 
	for(int i=2;i*i<=n;i++)
		while(n%i==0){
			if(c==0) {cout<<"Mike: Look at the result of my decomposition, I know: n is equal to "<<i; c++;} 
			else cout<<" multiply by "<<i;
			n/=i;
		}
	if(c==0) cout<<"MIke: And I also know "<<n<<" it's a prime number!"<<endl;
	else if(n>1) cout<<" multiply by "<<n<< "" <<endl;
	else cout<< "" <<endl;
}

int main(){
	while(1){
		string s;
		cout << "You: ";
		getline(cin,s);
		if(s=="") continue;
		if(s=="bye") 
			break; 
		else if(s.find("name")!=-1||s.find("who")!=-1) 
			cout<<"Mike: My name's Mike.'"<<endl; 
		else if(s.find("old")!=-1||s.find("how old")!=-1)
			cout<<"Mike: I am 100 years old! I cannot die!!!"<<endl;	
		else if(s.find("where")!=-1||s.find("where")!=-1)	
			cout<<"Mike: anywhere."<<endl; 
		else if(s.find("can")!=-1||s.find("specialty")!=-1)
			cout<<"Mike: I can only chat with you."<<endl;
		else if(s.find("birthday")!=-1)
			cout<<"Mike: My birthday is 2/29! Please give me the gift!!!"<<endl;
		else if(s.find("IQ")!=-1)
			cout<<"Mike: My IQ is 59."<<endl;
		else if(s.find("ball")!=-1||s.find("like")!=-1)
			cout<<"Mike: I love watching football, but I can't play football because I have no legs."<<endl;
		else if(s.find("joke")!=-1)
			cout<<"Mike: Tell you a joke: "<<endl<<joke[rand()%M]<<endl;
		else if(s.find("hi")!=-1 or s.find("hello")!=-1)
			cout<< "Mike: " << greet[rand()%M]<<endl;
		else if(allDigits(s)){
			cout<< "Mike: "<<s<<"is a good number"<<endl;
			decompose(s); 
		}
		else 
			cout<<sorry[rand()%M]<<endl;	
	}
	cout<<endl; 
	cout<<"Mike: Bye!"<<endl;
	exit(0);
}


