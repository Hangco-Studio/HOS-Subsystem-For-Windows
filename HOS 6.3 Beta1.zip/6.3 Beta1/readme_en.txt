HOS 6.2 is the new OS of HOS!
It has these updates:
    1:It has a web browser called 'pybrowser', it is using chromium.
    2.installer
    3.You can use Chinese.