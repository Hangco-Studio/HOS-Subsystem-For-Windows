import time
import os
try:
    import pygame
    os.system("cls")
except:
    print("Error: You can't use HOS without Pygame!")
    collectPygame = input("Do you want to install Pygame? (y/n) : ")
    if collectPygame == 'y' or collectPygame == 'Y':
        os.system("pip install pygame -i https://pypi.douban.com/simple")
    else:
        print("You havn't install Pygame!")
        time.sleep(1)
        exit(0)
print("-"*50)
print("Install HOS NT 6.2")
print("-"*50+"\n")
print("Step 1: Collect information")
language = input("Please enter the language that you use (en = English, zh = Chinese): ")
if language == 'en' or language == 'zh':
    file = open("language.HOS","w")
    file.write(language)
    file.close()
else:
    print("Error: InputError. Your input was wrong.")
    time.sleep(1)
    exit(0)
if language == 'en':
    username = input("Please enter your name: ")
    password = input("Please enter the new password: ")
    print("Step 2: Install files")
    print("Installing......")
    file = open("user.HOS","w")
    file.write(username)
    file = open("pass.HOS","w")
    file.write(password)
    file.close()
    print("Install Successfully!")
    time.sleep(1)
    exit(0)
elif language == 'zh':
    username = input("请输入您的姓名：")
    password = input("请输入新的密码：")
    print("第二步：增加文件")
    print("安装中。。。")
    file = open("user.HOS","w")
    file.write(username)
    file = open("pass.HOS","w")
    file.write(password)
    file.close()
    print("安装成功！")
    time.sleep(1)
    exit(0)
