print("Welcome to HOS(command prompt), you can type commandList for more information.")
while True:
    command = input("HOS-main >>>")

    if command == 'commandList':
        print("HOS-commandList: -command1 commandList\tHOS's command list")
        print("HOS-commandList: -command2 newFlie\tmake a new flie at this folder")
        print("HOS-commandList: -command3 openFlie\talter flies")
        print("HOS-commandList: -command4 seeFlie\tsee a flie")
        print("HOS-commandList: -command5 quit\tquit HOS")

    elif command == 'newFlie':
        flieName = input("HOS-newFlie/flieName >>>")
        if flieName == '':
            print("HOS-error/name_error: name '' is not a char")
            continue
        else:
            print("HOS-newFlie: creating......")
            newFlie = open(flieName,"w")
            flieContent = input("HOS-newFlie/flieContent >>>")
            newFlie.write(flieContent)
            print("HOS-newFlie: OK!")
            newFlie.close()

    elif command == 'openFlie':
        try:
            flieName = input("HOS-openFlie/flieName >>>")
            alterType = input("HOS-openFlie/alterType -w_or_a >>>")
            alterFlie = open(flieName,alterType)
            flieContent = input("HOS-openFlie/alter/flieContent >>>")
            print("alter......")
            alterFlie.write(flieContent)
            print("OK!")
            alterFlie.close()
        except:
            print("HOS-error/flie_error: No such flie named " + flieName +".")
            continue

    elif command == 'seeFlie':
        try:
            flieName = input("HOS-seeFlie/flieName >>>")
            seeFlie = open(flieName,"r")
            text = seeFlie.readline()
            seeFlie.close()
            print("HOS-seeFlie:",text)
        except:
            print("HOS-error/flie_error: No such flie named " + flieName +".")
            continue

    elif command == 'quit':
        break
    
    else:
        if command == '':
            continue
        else:
            print("HOS-error/command_error: command '",command,"' is a bad command.")
