import random
import sys
import datetime
from datetime import datetime
try:
    user = open("user.HOS","r")
    username = user.readline()
    user.close()
except:
    username = input("HOS-user: What's your name?\nPlease type your name here:")
    user = open("user.HOS","w")
    user.write(username)
    user.close()
print("HOS-welcome: "+username+", welcome to HOS(Hangco Oprating System)! You can type 'commandList' for more information.")
while True:
    command = input("HOS-main >>>")

    if command == 'commandList':
        print("HOS-commandList: -command1 commandList\tHOS's command list")
        print("HOS-commandList: -command2 newFile\tmake a new file.")
        print("HOS-commandList: -command3 openFile\talter files")
        print("HOS-commandList: -command4 seeFile\tsee a file")
        print("HOS-commandList: -command5 quit\tquit HOS")
        print("HOS-commandList: -command6 ver\tOutput version.")
        print("HOS-commandList: -command7 time\tOutput time.")
        print("HOS-commandList: -command8 sys\tOutput system's version.")

    elif command == 'newFile':
        fileName = input("HOS-newFile/fileName >>>")
        if fileName == '':
            print("HOS-error/name_error: name '' is not a char")
            continue
        else:
            print("HOS-newFile: Creating......")
            newFile = open(fileName,"w")
            fileContent = input("HOS-newFile/fileContent >>>")
            newFile.write(fileContent)
            print("HOS-newFile: OK!")
            newFile.close()

    elif command == 'openFile':
        try:
            fileName = input("HOS-openFile/fileName >>>")
            alterType = input("HOS-openFile/alterType -Write_or_Add >>>")
            alterFile = open(fileName,alterType)
            fileContent = input("HOS-openFile/alter/fileContent >>>")
            print("alter......")
            alterFile.write(fileContent)
            print("OK!")
            alterFile.close()
        except:
            print("HOS-error/file_error: No such file named " + fileName +".")
            continue

    elif command == 'seeFile':
        try:
            fileName = input("HOS-seeFile/fileName >>>")
            seeFile = open(fileName,"r")
            text = seeFile.readline()
            seeFile.close()
            print("HOS-seeFile:",text)
        except:
            print("HOS-error/file_error: No such file named " + fileName +".")
            continue

    elif command == 'ver':
        print("HOS-ver/ver: Hangco Oprating System Version2.4 on Windows(R) 10 (Python-3.8.5_on_Microsoft-DOS)")

    elif command == 'quit':
        print("HOS-quit: quiting...")
        break

    elif command == 'time':
        print("HOS/time: ",datetime.now())
    
    elif command == 'sys':
        print("HOS/about_Windows:", sys.platform)
        print("HOS/python_version:", sys.version)
        print("HOS/python_copyright:",sys.copyright)


    elif command == '':
        continue
    
    else:
        print("HOS-error/command_error: command '",command,"' is a bad command.")
