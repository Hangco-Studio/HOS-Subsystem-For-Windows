import random
import sys
import datetime
import time
import os
from datetime import datetime
def getWord():
    try:
        while True:
            password = input("HOS-password >>>")
            key1 = open("pass.HOS","r")
            key = key1.readline()
            key1.close()
            if password == key:
                print("HOS-password/pass: Pass!")
                break
            else:
                print("HOS-password: error!!!")
    except:
        password = input("HOS-password (Pease enter the new password.) >>>")
        key1 = open("pass.HOS","w")
        key1.write(password)
        key1.close()
        print("HOS-password: Please keep your password!(It is "+ password +".)")

def getName():
    try:
        user = open("user.HOS","r")
        username = user.readline()
        user.close()
    except:
        username = input("HOS-user: What's your name?\nPlease type your name here:")
        user = open("user.HOS","w")
        user.write(username)
        user.close()
    os.system('power1.wav')
    print("HOS-welcome: "+username+", welcome to HOS(Hangco Oprating System)! You can type 'commandList' for more information.")

def main():
    while True:
        command = input("HOS-main >>>")

        if command == 'commandList':
            print("HOS-commandList: -command1 commandList\tHOS's command list")
            print("HOS-commandList: -command2 file\t HOS's file system ")
            print("HOS-commandList: -command5 quit\tquit HOS")
            print("HOS-commandList: -command6 ver\tOutput version.")
            print("HOS-commandList: -command7 sys\tOutput your system(Not HOS!!!).")
            print("HOS-commandList: -command8 time\tHOS's time system.")
            print("HOS-commandList: -command9 cmd\tcmd(MS-DOS) on Microsoft Windows.")
            print("HOS-commandList: -commandX shell\tHOS's shell.")

        elif command == 'file':
            command = input("HOS-file/fileCommand (Please enter 'newFile', 'openFile' or 'seeFile') >>>")
        
            if command == 'newFile':
                fileName = input("HOS-newFile/fileName >>>")
                if fileName == '':
                    print("HOS-error/name_error: name '' is not a string")
                    continue
                else:
                    print("HOS-newFile: Creating......")
                    newFile = open(fileName,"w")
                    fileContent = input("HOS-newFile/fileContent >>>")
                    newFile.write(fileContent)
                    print("HOS-newFile: OK!")
                    newFile.close()

            elif command == 'openFile':
                try:
                    fileName = input("HOS-openFile/fileName >>>")
                    alterType = input("HOS-openFile/alterType -Write_or_Add >>>")
                    alterFile = open(fileName,alterType)
                    fileContent = input("HOS-openFile/alter/fileContent >>>")
                    print("alter......")
                    alterFile.write(fileContent)
                    print("OK!")
                    alterFile.close()
                except:
                    print("HOS-error/file_error: No such file named " + fileName +".")
                    continue

            elif command == 'seeFile':
                try:
                    fileName = input("HOS-seeFile/fileName >>>")
                    seeFile = open(fileName,"r")
                    text = seeFile.readline()
                    seeFile.close()
                    print("HOS-seeFile:",text)
                except:
                    print("HOS-error/file_error: No such file named " + fileName +".")
                    continue

        elif command == 'ver':
                print("HOS-ver/ver: Hangco Oprating System 5.0 on Windows(R) 10 (Python-3.8.5_on_CMD)")

        elif command == 'quit':
            print("HOS-quit: quiting...")
            os.system('power2.wav')
            break

        elif command == 'time':
            command = input("HOS/time (What do you want? time or timer) >>>")

            if command == 'time':
                print("HOS/time: ",datetime.now())

            elif command == 'timer':
                ttime = input("HOS-timer/timer (How much time do you want to time? Please enter) >>>")
                itime = int(ttime)
                while itime >= 0:
                    time.sleep(1)
                    itime = itime - 1
                print("HOS-timer/Time_over: Time over!!!")
    
        elif command == 'sys':
            print("HOS/about_Windows:", sys.platform)
            print("HOS/python_version:", sys.version)
            print("HOS/python_copyright:",sys.copyright)
            os.system('winver')

        elif command == 'cmd':
            os.system('cmd')

        elif command == 'shell':
            print("HOS-Shell: The prompt will change...")
            time.sleep(1)
            print("OK!")
            while True:
                command = input("Shell value $")

                if command == 'help':
                    command = input("help value $")
                    if command == 'newfile':
                        print("newfile command is a command that make a file.")
                    elif command == 'openfile':
                        print("openfile command is a command that alter a file.")
                    elif command == 'seefile':
                        print("seefile command is a command that see a file.")
                    elif comamdn == 'quit':
                        break
                    else:
                        print("err command, pls try again!")
            
        elif command == '':
            continue
    
        else:
            print("HOS-error/command_error: command '",command,"' is a bad command.")


getWord()
getName()
main()
