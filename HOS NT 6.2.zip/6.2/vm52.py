import random
import sys
import datetime
import time
import os
from datetime import datetime
print("Please install pygame.")
time.sleep(1)
def getWord():
    try:
        while True:
            password = input("HOS-password >>>")
            key1 = open("pass.HOS","r")
            key = key1.readline()
            key1.close()
            if password == key:
                print("HOS-password/pass: Pass!")
                break
            else:
                print("HOS-password: error!!!")
    except:
        password = input("HOS-password (Pease enter the new password.) >>>")
        key1 = open("pass.HOS","w")
        key1.write(password)
        key1.close()
        print("HOS-password: Please keep your password!(It is "+ password +".)")

def getName():
    try:
        user = open("user.HOS","r")
        username = user.readline()
        user.close()
    except:
        username = input("HOS-user: What's your name?\nPlease type your name here:")
        user = open("user.HOS","w")
        user.write(username)
        user.close()
    import pygame
    sound = r'power1.wav'
    pygame.mixer.init()
    track = pygame.mixer.music.load(sound)
    pygame.mixer.music.play()
    time.sleep(10)
    pygame.mixer.music.stop()
    print("HOS-welcome: "+username+", welcome to HOS(Hangco Oprating System)! You can type 'commandList' for more information.")

def main():
    while True:
        command = input("HOS-main >>>")

        if command == 'commandList':
            print("HOS-commandList: -command1 commandList\tHOS's command list")
            print("HOS-commandList: -command2 file\t HOS's file system ")
            print("HOS-commandList: -command5 quit\tquit HOS")
            print("HOS-commandList: -command6 ver\tOutput version.")
            print("HOS-commandList: -command7 sys\tOutput your system(Not HOS!!!).")
            print("HOS-commandList: -command8 time\tHOS's time system.")
            print("HOS-commandList: -command9 cmd\tcmd(MS-DOS) on Microsoft Windows.")

        elif command == 'file':
            command = input("HOS-file/fileCommand (Please enter 'newFile', 'openFile' or 'seeFile' or 'delFile') >>>")
        
            if command == 'newFile':
                fileName = input("HOS-newFile/fileName >>>")
                if fileName == '':
                    print("HOS-error/name_error: name '' is not a string")
                    continue
                else:
                    print("HOS-newFile: Creating......")
                    newFile = open(fileName,"w")
                    fileContent = input("HOS-newFile/fileContent >>>")
                    newFile.write(fileContent)
                    print("HOS-newFile: OK!")
                    newFile.close()

            elif command == 'openFile':
                try:
                    fileName = input("HOS-openFile/fileName >>>")
                    alterType = input("HOS-openFile/alterType -Write_or_Add >>>")
                    alterFile = open(fileName,alterType)
                    fileContent = input("HOS-openFile/alter/fileContent >>>")
                    print("alter......")
                    alterFile.write(fileContent)
                    print("OK!")
                    alterFile.close()
                except:
                    print("HOS-error/file_error: No such file named " + fileName +".")
                    continue

            elif command == 'seeFile':
                try:
                    fileName = input("HOS-seeFile/fileName >>>")
                    seeFile = open(fileName,"r")
                    text = seeFile.readline()
                    seeFile.close()
                    print("HOS-seeFile:",text)
                except:
                    print("HOS-error/file_error: No such file named " + fileName +".")
                    continue          

            elif command == 'delFile':
                try:
                    fileName = input("HOS-delFile/fileName >>>")
                    tf = input("HOS-delFile/really (Do you really want to delete this file ? (t/f)) >>>")
                    if tf == 't' or tf == 'T':
                        os.remove(fileName)
                    elif tf == 'f' or tf == 'F':
                        continue

                except:
                    print("HOS-error/name "+command+" is not defined.")
                    continue

        elif command == 'ver':
            print("HOS-ver/ver: Hangco OS NT V5.2")

        elif command == 'quit':
            import pygame
            print("HOS-quit: quiting...")
            sound = r'power2.wav'
            pygame.mixer.init()
            track = pygame.mixer.music.load(sound)
            pygame.mixer.music.play()
            time.sleep(10)
            pygame.mixer.music.stop()
            break

        elif command == 'time':
            command = input("HOS/time (What do you want? time or timer) >>>")

            if command == 'time':
                print("HOS/time: ",datetime.now())

            elif command == 'timer':
                ttime = input("HOS-timer/timer (How much time do you want to time? Please enter) >>>")
                itime = int(ttime)
                while itime >= 0:
                    time.sleep(1)
                    itime = itime - 1
                print("HOS-timer/Time_over: Time over!!!")
    
        elif command == 'sys':
            print("HOS/about_Windows:", sys.platform)
            print("HOS/python_version:", sys.version)
            print("HOS/python_copyright:",sys.copyright)
            os.system('winver')

        elif command == 'cmd':
            os.system('cmd')

            
        elif command == '':
            continue
    
        else:
            print("HOS-error/command_error: command '",command,"' is a bad command.")


getWord()
getName()
main()
