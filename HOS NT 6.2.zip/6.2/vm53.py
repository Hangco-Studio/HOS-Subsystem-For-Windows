import random
import sys
import datetime
import time
import os
try:
    import pygame
except:
    print("HOS-error/module_error: You havn't install pygame yet!")
    quit()
from datetime import datetime
def getWord():
    try:
        key1 = open("pass.HOS","r")
        key = key1.readline()
        key1.close()
        while True:
            if key == '':
                break
            password = input("HOS-password >>>")
            if password == key:
                print("HOS-password/pass: Pass!")
                break
            else:
                print("HOS-password: error!!!")
    except:
        password = input("HOS-password (Pease enter the new password.) >>>")
        key1 = open("pass.HOS","w")
        key1.write(password)
        key1.close()

def getName():
    try:
        user = open("user.HOS","r")
        username = user.readline()
        user.close()
    except:
        username = input("HOS-user: (Please enter your name) >>>")
        user = open("user.HOS","w")
        user.write(username)
        user.close()
    sound = r'power1.wav'
    pygame.mixer.init()
    track = pygame.mixer.music.load(sound)
    pygame.mixer.music.play()
    time.sleep(10)
    pygame.mixer.music.stop()
    print("HOS-welcome: "+username+", welcome to HOS(Hangco Oprating System)! You can type 'commandList' for more information.")

def main():
    while True:
        command = input("HOS-main >>>")

        if command == 'commandList':
            print("HOS-commandList: -command1 commandList\tHOS's command list")
            print("HOS-commandList: -command2 file\t HOS's file system ")
            print("HOS-commandList: -command5 quit\tquit HOS")
            print("HOS-commandList: -command6 ver\tOutput version.")
            print("HOS-commandList: -command7 sys\tOutput your system(Not HOS!!!).")
            print("HOS-commandList: -command8 time\tHOS's time system.")
            print("HOS-commandList: -command9 command\tcommand prompt.")
            print("HOS-commandList: -commandX run\trun program.")
            print("HOS-commandList: -command11 rerun\trerun HOS.")

        elif command == 'file':
            command = input("HOS-file/fileCommand (Please enter 'newFile', 'openFile', 'seeFile' or 'delFile') >>>")
        
            if command == 'newFile':
                fileName = input("HOS-newFile/fileName >>>")
                try:
                    if fileName == '':
                        print("HOS-error/name_error: name '' is not a string")
                        continue
                    else:
                        print("HOS-newFile: Creating......")
                        newFile = open(fileName,"w")
                        fileContent = input("HOS-newFile/fileContent >>>")
                        newFile.write(fileContent)
                        print("HOS-newFile: OK!")
                        newFile.close()
                except PermissionError:
                    print("HOS-error/PermissionError: fileName is "+fileName+", it is not true.")

            elif command == 'openFile':
                try:
                    fileName = input("HOS-openFile/fileName >>>")
                    alterType = input("HOS-openFile/alterType -Write_or_Add >>>")
                    alterFile = open(fileName,alterType)
                    fileContent = input("HOS-openFile/alter/fileContent >>>")
                    print("alter......")
                    alterFile.write(fileContent)
                    print("OK!")
                    alterFile.close()
                except:
                    print("HOS-error/file_error: No such file named " + fileName +".")
                    continue

            elif command == 'seeFile':
                try:
                    fileName = input("HOS-seeFile/fileName >>>")
                    seeFile = open(fileName,"r")
                    text = seeFile.readline()
                    seeFile.close()
                    print("HOS-seeFile:",text)
                except:
                    print("HOS-error/file_error: No such file named " + fileName +".")
                    continue          

            elif command == 'delFile':
                try:
                    fileName = input("HOS-delFile/fileName >>>")
                    yn = input("HOS-delFile/really (Do you really want to delete this file ? (Y/N)) >>>")
                    if yn == 'Y' or yn == 'y':
                        os.remove(fileName)
                    elif yn == 'N' or yn == 'n':
                        continue

                except:
                    print("HOS-error/name "+command+" not found.")
                    continue

            else:
                print("HOS-error/commandError: "+command+" not found.")
                continue

        elif command == 'ver':
            print("HOS-ver/ver: Hangco OS NT V5.3")

        elif command == 'quit':
            print("HOS-quit: Quit sucessfully.")
            sound = r'power2.wav'
            pygame.mixer.init()
            track = pygame.mixer.music.load(sound)
            pygame.mixer.music.play()
            time.sleep(10)
            pygame.mixer.music.stop()
            break

        elif command == 'time':
            command = input("HOS/time (What do you want? time or timer) >>>")

            if command == 'time':
                print("HOS/time: ",datetime.now())

            elif command == 'timer':
                ttime = input("HOS-timer/timer (How much time do you want to time? Please enter) >>>")
                itime = int(ttime)
                while itime >= 0:
                    time.sleep(1)
                    itime = itime - 1
                print("HOS-timer/Time_over: Time over!!!")

            else:
                print("HOS-error/commandError: command "+command+" not found.")
                continue
    
        elif command == 'sys':
            print("HOS/about_OS:", sys.platform)
            print("HOS/python_version:", sys.version)
            print("HOS/python_copyright:",sys.copyright)

        elif command == 'command':
            while True:
                cmd = input("HOS-command $ ")
                if cmd == 'exit':
                    break
                else:
                    os.system(cmd)

        elif command == 'run':
            program = input("HOS-run/program (Please enter what program do you want to run) >>>")
            os.system(program)

        elif command == 'vm':
            vm = input("HOS-vm/select_vm (Please select vm: 1.0, 3.0, 4.2.0, 4.2.1, 4.2.2, 4.2.3, 5.0, 5.1, 5.2, 5.3) >>>")
            if vm == '1.0':
                os.system("vm10.py")
            elif vm == '3.0':
                os.system("vm30.py")
            elif vm == '4.2.0':
                os.system("vm420.py")
            elif vm == '4.2.1':
                os.system("vm421.py")
            elif vm == '4.2.2':
                os.system("vm422.py")
            elif vm == '4.2.3':
                os.system("vm423.py")
            elif vm == '5.0':
                os.system("vm50.py")
            elif vm == '5.1':
                os.system("vm51.py")
            elif vm == '5.2':
                os.system("vm52.py")

        elif command == '':
            continue
    
        else:
            print("HOS-error/command_error: command '",command,"' is a bad command.")

getWord()
getName()
main()
