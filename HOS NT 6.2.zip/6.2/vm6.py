import random
import sys
import datetime
from datetime import datetime
try:
    user = open("user.HOS","r")
    username = user.readline()
    user.close()
except:
    username = input("username >>>")
    user = open("user.HOS","w")
    user.write(username)
    user.close()
print("Aser OS ©2020 All right reserved")
print("Type 'cmdlist' for help")
while True:
    command = input("main >>>")

    if command == 'cmdlist':
        print("commandList: command1 commandList\s command list")
        print("commandList: command2 newFile\make a new file.")
        print("commandList: command3 openFile\alter files")
        print("commandList: command4 seeFile\see a file")
        print("commandList: command5 quit\quit ")
        print("commandList: command6 ver\Output version.")
        print("commandList: command7 time\print datetime")
        print("commandList: command8 sys\print ver-copyright-platform")
    
    elif command == 'newfile':
        fileName = input("newFile/fileName >>>")
        if fileName == '':
            print("Error/name_error: name '' is not a char")
            continue
        else:
            print("newFile: Creating......")
            newFile = open(fileName,"w")
            fileContent = input("newFile/fileContent >>>")
            newFile.write(fileContent)
            print("Done")
            newFile.close()

    elif command == 'openfile':
        try:
            fileName = input("openFile/fileName >>>")
            alterType = input("openFile/alterType -Write_or_Add >>>")
            alterFile = open(fileName,alterType)
            fileContent = input("openFile/alter/fileContent >>>")
            print("alter......")
            alterFile.write(fileContent)
            print("Done")
            alterFile.close()
        except:
            print("Error/file_error: No such file named " + fileName +".")
            continue

    elif command == 'seefile':
        try:
            fileName = input("seeFile/fileName >>>")
            seeFile = open(fileName,"r")
            text = seeFile.readline()
            seeFile.close()
            print("seeFile:",text)
        except:
            print("Error/file_error: No such file named " + fileName +".")
            continue

    elif command == 'ver':
        print("ver/ver: Hangco Oprating System Version2.4 on Windows(R) 10 (Python-3.8.5_on_Microsoft-DOS)")
        print("ver/aserver: Aser Oprating System Version1.0 on Windows(R) 10 (Python-3.6_on_Microsoft-CMD)")

    elif command == 'quit':
        print("Quit: quiting...")
        break

    elif command == 'time':
        print(datetime.now())
    
    elif command == 'sys':
        print("about windows:", sys.platform)
        print("python ver:", sys.version)
        print("python copyright:",sys.copyright)

    elif command == '':
        continue
    
    else:
        print("Error/command_error: command '",command,"' is a bad command.")
