import random
import sys
import datetime
import time
import os
from datetime import datetime
try:
    import pygame
    pygame.mixer.init()
except:
    print("Your havn't install 'pygame' module yet!")
    time.sleep(1)
    exit()
def getWord():
    try:
        file = open("pass.HOS","r")
        key = file.readline()
        file.close()
        while True:
            if key == '':
                break
            password = input("Please enter the password : ")
            if password == key:
                print("Pass!")
                break
            else:
                print("Your password is wrong!!!")
    except:
        password = input("Please enter the new password : ")
        key1 = open("pass.HOS","w")
        key1.write(password)
        key1.close()

def getName():
    try:
        user = open("user.HOS","r")
        username = user.readline()
        user.close()
    except:
        username = input("Please enter your name : ")
        user = open("user.HOS","w")
        user.write(username)
        user.close()
    sound = pygame.mixer.Sound("power1.wav")
    sound.play()
    print("Welcome to HOS, "+username+"! You can enter 'commandList' for more information.\nCopyright Hangco Inc. All rights reserved.")

def main():
    file = open("user.HOS")
    username = file.readline()
    file.close()
    while True:
        command = input("[username: "+username+"] $ ")

        if command == 'commandList':
            print("-"*50)
            print("Command1: commandList\tHOS's command list")
            print("Command2: file\t HOS's file system ")
            print("Command3: quit\tquit HOS")
            print("Command4: ver\tOutput version.")
            print("Command5: sys\tOutput your system(Not HOS!!!).")
            print("Command6: time\tHOS's time system.")
            print("Command7: command\tcommand prompt.")
            print("Command8: vm\tHOS's vms.")
            print("Command9: readme\tsome readme text.")
            print("Command10: setup\tHOS's setup.")
            print("Command11: jackpot\tjackpot game.")
            print("Command12: chatbot\tchat with mike, a chat robot.")
            print("-"*50)

        elif command == 'file':
            print("-"*50)
            command = input("Please enter 'newFile', 'alterFile', 'seeFile', 'delFile': ")
        
            if command == 'newFile':
                fileName = input("Please enter the new file's name : ")
                try:
                    if fileName == '':
                        print("Error!")
                        continue
                    else:
                        print("Creating......")
                        newFile = open(fileName,"w")
                        fileContent = input("Please enter the new file's content : ")
                        newFile.write(fileContent)
                        print("Create Sucsessfully!")
                        newFile.close()
                except PermissionError:
                    print("PermissionError!")
                    continue

            elif command == 'alterFile':
                try:
                    fileName = input("Please enter the file's name that you want to alter : ")
                    alterType = input("Please enter the type that you want to alter (w/a, w is write, a is add) : ")
                    alterFile = open(fileName,alterType)
                    if alterType == 'w':
                        fileContent = input("Please enter the new file content that you want to alter : ")
                    elif alterType == 'a':
                        fileContent = input("Please enter the file content that you want to add : ")
                    print("Altering......")
                    alterFile.write(fileContent)
                    print("Alter sucsessfully!")
                    alterFile.close()
                except:
                    print("No such file named " + fileName +"!")
                    continue

            elif command == 'seeFile':
                try:
                    fileName = input("Please enter the file's name that you want to see : ")
                    seeFile = open(fileName,"r")
                    text = seeFile.readline()
                    seeFile.close()
                    print(text)
                except:
                    print("No such file named " + fileName +"!")
                    continue          

            elif command == 'delFile':
                try:
                    fileName = input("Please enter the file's name that you want to delete : ")
                    yn = input("Do you really want to delete this file? (y/n) : ")
                    if yn == 'Y' or yn == 'y':
                        os.remove(fileName)
                    elif yn == 'N' or yn == 'n':
                        continue
                except:
                    print("Name "+command+" not found!")
                    continue

            else:
                print("Name "+command+" not found!")
                continue

            print("-"*50)

        elif command == 'ver':
            print("-"*50)
            print("HOS NT V6.1 , Built on 20200909SP002 Technology, Codename: New Apps")
            print("-"*50)

        elif command == 'quit':
            print("-"*50)
            print("Quit sucessfully.")
            print("-"*50)
            sound = r'power2.wav'
            track = pygame.mixer.music.load(sound)
            pygame.mixer.music.play()
            time.sleep(10)
            pygame.mixer.music.stop()
            break

        elif command == 'time':
            print("-"*50)
            command = input("What do you want? time or timer : ")

            if command == 'time':
                print(datetime.now())

            elif command == 'timer':
                ttime = input("How much time do you want to time? : ")
                itime = int(ttime)
                while itime >= 0:
                    time.sleep(1.00000)
                    itime = itime - 1
                print("Time over!!!")
                sound = pygame.mixer.Sound("timeOver.wav")
                sound.play()

            else:
                print("Command "+command+" not found!")
                continue

            print("-"*50)
    
        elif command == 'sys':
            print("-"*50)
            print("Your os is ", sys.platform)
            print("Your python's version is ", sys.version)
            print(sys.copyright)
            print("-"*50)

        elif command == 'command':
            print("-"*50)
            while True:
                cmd = input("Command Prompt $ ")
                if cmd == 'exit':
                    print("-"*50)
                    break
                else:
                    os.system(cmd)

        elif command == 'vm':
            vm = input("Please select vm: 1.0, 3.0, 4.2.0, 4.2.1, 4.2.2, 4.2.3, 5.0, 5.1, 5.2, 5.3 or 6, X, XI, XI2 : ")
            if vm == '1.0':
                os.system("vm10.py")
            elif vm == '3.0':
                os.system("vm30.py")
            elif vm == '4.2.0':
                os.system("vm420.py")
            elif vm == '4.2.1':
                os.system("vm421.py")
            elif vm == '4.2.2':
                os.system("vm422.py")
            elif vm == '4.2.3':
                os.system("vm423.py")
            elif vm == '5.0':
                os.system("vm50.py")
            elif vm == '5.1':
                os.system("vm51.py")
            elif vm == '5.2':
                os.system("vm52.py")
            elif vm == '5.3':
                os.system("vm53.py")
            elif vm == '6':
                os.system("vm6.py")
            elif vm == 'X' or vm == 'x':
                os.system("vmX.py")
            elif vm == 'XI' or vm == 'xi' or vm == 'xI' or vm == 'Xi':
                os.system("vmXI.py")
            elif vm == 'XI2' or vm == 'xi2' or vm == 'xI2' or vm == 'Xi2':
                os.system("vmXI2.py")
            else:
                print("OS "+vm+" not found.")

        elif command == 'readme':
            print("-"*50)
            file = open("readme.txt","r")
            readme = file.readline()
            print(readme)
            for text in readme:
                readme = file.readline()
                print(readme)
                if not readme:
                    print("-"*50)
                    break

        elif command == 'setup':
            print("-"*50)
            password = input("Please enter the password to continue : ")
            file = open("pass.HOS")
            key = file.readline()
            file.close()
            if password == key:
                print("Pass!")
                command = input("Please enter setup command 'password' or 'shutdown' : ")
                if command == 'password':
                    file = open("pass.HOS","w")
                    password = input("Please enter the new password : ")
                    file.write(password)
                    print("Alter Succsessfully")
                    file.close()
                elif command == 'shutdown':
                    if sys.platform == 'win32' or sys.platform == 'win64':
                        os.system("shutdown -s -t 0")
                    else:
                        print("This process requird Microsoft Windows.")
                        time.sleep(1)
                        break
            else:
                print("Your password is wrong!")
                print("-"*50)
                continue
            print("-"*50)

        elif command == 'jackpot':
            os.system("jackpot.exe")
            print("**this game is end**")

        elif command == 'chatbot':
            os.system("chatbot.exe")

        elif command == '':
            continue
    
        else:
            print("-"*50)
            print("Command '",command,"' is a bad command!")
            print("-"*50)

getWord()
getName()
main()
