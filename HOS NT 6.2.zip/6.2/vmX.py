import random
import sys
import time
import datetime
from datetime import datetime

print("Starting BIOS...")
time.sleep(1)
print("Starting System...")
time.sleep(1)
print(" ")
try:
    user = open("user.HOS", "r")
    username = user.readline()
    user.close()
except:
    username = input('username >>>')
    user = open("user.HOS", "w")
    user.write(username)
    user.close()
print('Aser Oprating System ©2020 All right reserved')
time.sleep(0.5)
print("Type 'cmdlist' for help")
while True:
    command = input('>>>')
    if command == 'cmdlist':
        print('commandList: command1 cmdlist\s command list')
        print('commandList: command2 newfile\make a new file.')
        print('commandList: command3 openfile\alter files')
        print('commandList: command4 seefile\see a file')
        print('commandList: command5 quit\quit ')
        print('commandList: command6 ver\Output version.')
        print('commandList: command7 time\print datetime')
        print('commandList: command8 sys\print ver-copyright-platform')
    elif command == 'newfile':
        fileName = input('newfile/fileName >>>')
        if (fileName == ''):
            print("Error/name_error: name '' is not a char")
            continue
        else:
            print('newFile: Creating......')
            newFile = open(fileName, "w")
            fileContent = input('newfile/fileContent >>>')
            newFile.write(fileContent)
            print('Done')
            newFile.close()
    elif command == 'openfile':
        try:
            fileName = input('openfile/fileName >>>')
            alterType = input('openfile/alterType -Write_or_Add >>>')
            alterFile = open(fileName, alterType)
            fileContent = input('openfile/alter/fileContent >>>')
            print('alter......')
            alterFile.write(fileContent)
            print('Done')
            alterFile.close()
        except:
            print((('Error/file_error: No such file named ' + fileName) + '.'))
            continue
    elif command == 'seefile':
        try:
            fileName = input('seefile/fileName >>>')
            seeFile = open(fileName, "r")
            text = seeFile.readline()
            seeFile.close()
            print('seefile:', text)
        except:
            print((('Error/file_error: No such file named ' + fileName) + '.'))
            continue
    elif command == 'ver':
        print('ver/ver: Hangco Oprating System Version2.4 on Windows(R) 10 (Python-3.8.5_on_Microsoft-DOS)')
        print('ver/aserver: Aser Oprating System Version1.0 on Windows(R) 10 (Python-3.6.5_on_Microsoft-CMD)')
    elif command == 'quit':
        print('Quit: quiting...')
        break
    elif command == 'time':
        print(datetime.now())
    elif command == 'sys':
        print('about windows:', sys.platform)
        print('python ver:', sys.version)
        print('python copyright:', sys.copyright)
    elif command == '':
        continue
    else:
        print("Error/command_error: command '", command, "' is a bad command.")
