import random
import sys
import time
import datetime
from datetime import datetime

print("Starting BIOS...")
time.sleep(1)
print("Starting System...")
time.sleep(1)
print(" ")
try:
    user = open("user.HOS", "r")
    username = user.readline()
    user.close()
except:
    username = input('username >>>')
    user = open("user.HOS", "w")
    user.write(username)
    user.close()
print('Aser Oprating System ©2020 All right reserved')
time.sleep(0.3)
print("Type 'cmdlist' for help")
while True:
    command = input('>>>')
    if command == 'cmdlist':
        print('commandList: command1 cmdlist\s command list')
        time.sleep(0.05)
        print('commandList: command2 newfile\make a new file.')
        time.sleep(0.05)
        print('commandList: command3 openfile\alter files')
        time.sleep(0.05)
        print('commandList: command4 seefile\see a file')
        time.sleep(0.05)
        print('commandList: command5 quit\quit ')
        time.sleep(0.05)
        print('commandList: command6 ver\Output version.')
        time.sleep(0.05)
        print('commandList: command7 time\print datetime')
        time.sleep(0.05)
        print('commandList: command8 sys\print ver-copyright-platform')
        time.sleep(0.05)
        print('commandList: command9 applist\show all apps')
    elif command == 'newfile':
        fileName = input('newfile/fileName >>>')
        if (fileName == ''):
            print("Error/name_error: name '' is not a char")
            continue
        else:
            print('newFile: Creating......')
            newFile = open(fileName, "w")
            fileContent = input('newfile/fileContent >>>')
            newFile.write(fileContent)
            print('Done')
            newFile.close()
    elif command == 'openfile':
        try:
            fileName = input('openfile/fileName >>>')
            alterType = input('openfile/alterType -Write_or_Add >>>')
            alterFile = open(fileName, alterType)
            fileContent = input('openfile/alter/fileContent >>>')
            print('alter......')
            alterFile.write(fileContent)
            print('Done')
            alterFile.close()
        except:
            print((('Error/file_error: Cannot find ' + fileName) + '.'))
            continue
    elif command == 'seefile':
        try:
            fileName = input('seefile/fileName >>>')
            seeFile = open(fileName, "r")
            text = seeFile.readline()
            seeFile.close()
            print('seefile:', text)
        except:
            print((('Error/file_error: Cannot find ' + fileName) + '.'))
            continue
    elif command == 'ver':
        print("ver/HOSver: Hangco Oprating System Version3.0")
        time.sleep(0.05)
        print("ver/Environment: on Windows(R) 10 Python-3.6.5")
        time.sleep(0.05)
        print("ver/AserOSver: Aser Oprating System Version 10.9")
        time.sleep(0.05)
        print("ver/Copyright: Aser Technology ©2020 Allright reserved")
        time.sleep(0.05)
        print("ver/Vernumber: 2020-8050-828-1009")
    elif command == 'quit':
        print('Closing...')
        time.sleep(0.5)
        break
    elif command == 'time':
        print(datetime.now())
    elif command == 'sys':
        print('about windows:', sys.platform)
        time.sleep(0.05)
        print('python ver:', sys.version)
        time.sleep(0.05)
        print('python copyright:', sys.copyright)
    elif command == 'applist':
        print("<applist>")
        time.sleep(0.05)
        print("Aser Vitual System<aservs>")
        time.sleep(0.05)
        print("Python Shell<shell>")
    elif command == "aservs":
        print(" >Aser Vitual System <Aser.inc ©2020 All right reserved>")
        time.sleep(1)
        print(" ")
        print(" Starting Vitual Machine...")
        time.sleep(1)
        print(" Installing BIOS...")
        time.sleep(1)
        print(" Installing System...")
        time.sleep(3)
        print(" ")
        print(" Zore OS 4.3")
        time.sleep(0.05)
        print(" Type list for command list")
        while True:
            cmd = input(" >")
            if cmd == 'list':
                print(" list > list/output command list")
                time.sleep(0.05)
                print(" list > ver/check Zore OS version")
                time.sleep(0.05)
                print(" list > new/create a new file")
                time.sleep(0.05)
                print(" list > open/open a file")
                time.sleep(0.05)
                print(" list > time/check datetime")
                time.sleep(0.05)
                print(" list > logout/close Zore OS")
            elif cmd == 'ver':
                print(" ver > Zore Oprating System ©2020 All right reserved")
                time.sleep(0.05)
                print(" Copyright > Aser Technology.inc")
                time.sleep(0.05)
                print(" num > 2080-5084-70-021")
            elif cmd == 'new':
                fname = input(' Filename >')
                if (fname == ''):
                    print(" error > Filename cannot be empty")
                    continue
                else:
                    print(' >creating... ')
                    newf = open(fname, "w")
                    fc = input(' write >')
                    newf.write(fc)
                    print(' Done')
                    newf.close()
            elif cmd == 'open':
                try:
                    fname = input(' FileName >')
                    seef = open(fname, "r")
                    txt = seef.readline()
                    seef.close()
                    print(' File/', txt)
                except:
                    print(' error > Cannot find the file')
                    continue
            elif cmd == 'time':
                print(' ',datetime.now())
            elif cmd == 'logout':
                print(" Closing...")
                time.sleep(3)
                break
            elif cmd == '':
                continue
            else:
                print(" error > Cannot find '",cmd,"'")
    elif command == 'shell':
        print(" </> python shell build 3.6.5")
        while True:
            shell = input(" $ ")
            if shell == 'platform':
                print(" ",sys.platform)
            elif shell == 'version':
                print(" ",sys.version)
            elif shell == 'copyright':
                print(" ",sys.copyright)
            elif shell == 'quit':
                break
            else:
                print(" error python command")
                continue
    elif command == '':
        continue
    else:
        print("Error/command_error: Cannot find '", command, "'")
